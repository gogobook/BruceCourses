ESP8266-Config
==============
Program by : [AppStack](http://www.facebook.com/appstack.in.th) ,Thailand  
Programmer : @Svl2Nuk3  ,  @UltraMCU  
Thanks     : [Ayarafun](https://www.facebook.com/ayarafun.club) , [RaspberyPi 66 Club](https://www.facebook.com/RaspberryPi66)  


Require
------------------
.NET Framework 3.5


User guide
------------------
1. Connect serial and ESP8266 module.
2. Open ESP8266 Config.  
   2.1 Select serial port.  
   2.2 Select Baudrate.  
   2.3 Connect.  
3. Waiting for value of mode , mux and firmware version. After that program will be enable.
4. Enjoy,Please notify us if you get error.
